import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('VoteTable')

def lambda_handler(event, context):
    body = json.loads(event['body'])
    vote = body.get('vote')

    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*'
    }

    if vote not in ['cats', 'dogs']:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'message': 'Invalid vote'})
        }

    table.update_item(
        Key={'candidate': vote},
        UpdateExpression="ADD #v :inc",
        ExpressionAttributeNames={"#v": "votes"},
        ExpressionAttributeValues={":inc": 1}
    )

    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps({'message': 'Vote counted for ' + vote})
    }

