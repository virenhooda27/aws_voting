import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('VoteTable')

def lambda_handler(event, context):
    results = {}
    for candidate in ['cats', 'dogs']:
        response = table.get_item(Key={'candidate': candidate})
        votes = response.get('Item', {}).get('votes', 0)
        results[candidate] = int(votes) if isinstance(votes, Decimal) else votes

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Methods': 'POST,OPTIONS'
        },
        'body': json.dumps(results)
    }
